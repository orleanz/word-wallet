# word-wallet
Chrome extension that allows you to paste words from pre-defined list via context menu click directly to input fields on webpages. 

Installation from Chrome Store:

https://chrome.google.com/webstore/detail/word-wallet/pdajfgebhmdfkmmjpbhiokibkdheneil
